<?php
namespace wstshop\admin\model;
use think\Db;
/**
 * ============================================================================
 * WSTShop网上商店
 * 版权所有 2016-2066 广州商淘信息科技有限公司，并保留所有权利。
 * 官网地址:http://www.wstshop.net
 * 交流社区:http://bbs.shangtaosoft.com
 * 联系QQ:153289970
 * ----------------------------------------------------------------------------
 * 这不是一个自由软件！未经本公司授权您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * 在线更新业务处理
 */
class Upgrade extends Base{
	public function updateVersion($version){
		Db::startTrans();
		try{
			// 执行sql
			$sql = ROOT_PATH.'upgrade/'.$version.'.sql';
			$sql = file_get_contents($sql);
			$sql = str_replace("\r", "\n", $sql);
			$ret = array();
			$num = 0;
			foreach(explode(";\n", trim($sql)) as $query) {
				$ret[$num] = '';
				$queries = explode("\n", trim($query));
				foreach($queries as $query) {
					$ret[$num] .= (isset($query[0]) && $query[0] == '#') || (isset($query[1]) && isset($query[1]) && $query[0].$query[1] == '--') ? '' : $query;
				}
				$num++;
			}
			unset($sql);
			foreach($ret as $query) {
				$query = trim($query);
				if($query) {
					if(strtoupper(substr($query, 0, 12)) == 'CREATE TABLE') {
						$type = strtoupper(preg_replace("/^\s*CREATE TABLE\s+.+\s+\(.+?\).*(ENGINE|TYPE)\s*=\s*([a-z]+?).*$/isU", "\\2", $query));
			            $query = preg_replace("/^\s*(CREATE TABLE\s+.+\s+\(.+?\)).*$/isU", "\\1", $query)." ENGINE=InnoDB DEFAULT CHARSET=utf8";
					}
					Db::execute($query);
				}
			}

			// 更新版本号
			Db::name('sys_configs')->where('fieldCode="wstVersion"')->setField('fieldValue',$version);
			Db::commit();
			return WSTReturn('更新成功',1);
		}catch(\Exception $e){
			Db::rollback();
		}
		return WSTReturn('数据库更新失败',-1);
	}
	
}
