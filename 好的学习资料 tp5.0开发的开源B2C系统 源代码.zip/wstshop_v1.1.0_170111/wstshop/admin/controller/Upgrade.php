<?php
namespace wstshop\admin\controller;
/**
 * ============================================================================
 * WSTShop网上商店
 * 版权所有 2016-2066 广州商淘信息科技有限公司，并保留所有权利。
 * 官网地址:http://www.wstshop.net
 * 交流社区:http://bbs.shangtaosoft.com
 * 联系QQ:153289970
 * ----------------------------------------------------------------------------
 * 这不是一个自由软件！未经本公司授权您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * 在线升级控制器
 */
class Upgrade extends Base{
    
    public function updatelist(){
        return $this->fetch('list');
    }
    // 根据传过来的版本号获取待更新的文件列表
    public function toUpdate(){
        //$version = input('v');
        $version = '1.0.1';
        $rs = db('version_update')->where('version',$version)->select();
        $this->assign('list',$rs);
        return $this->fetch('update');
    }
    public function update(){
        $version = input('version');
        $filePath = input('filePath');
        $url = 'http://iguoqin.cn/update.php'; // 要下载的文件【服务器】
        $savedir = ROOT_PATH.$filePath; // 下载后保存的路径【客户端】 
        $filename = $filePath; // 下载后保存的名字

        $rs = $this->getFile($url, $savedir, $filename, $version);
        if($rs===false){
            return WSTReturn('更新失败',-1);
        }
        
        return WSTReturn('更新成功',1);
    }
    /** 
     * @param $url        被下载的文件路径
     * @param $savedir    下载后保存的路径
     * @param $filename   下载后保存的文件名
    */
    public function getFile($url, $savedir = '', $filename = '', $version) {
            if (trim($url) == ''){
                return false;
            }
            if (trim($savedir) == ''){
                return false;
            }
            $dir = strrchr($savedir,'/');
            $dir = str_replace($dir,'',$savedir);
            //创建保存目录
            if (!file_exists($dir) && !mkdir($dir, 0777, true)){
                return false;
            }
            //获取远程文件
            $ch = curl_init();
            $timeout = 5;
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);

            // 模拟post
            $data = [
                    'version'=>$version,
                    'savedir' => $filename, 
            ];
            curl_setopt ( $ch, CURLOPT_POSTFIELDS, $data );
            $content = curl_exec($ch);
            $httpCode = curl_getinfo($ch,CURLINFO_HTTP_CODE); 
            if($httpCode==403){
                curl_close($ch);
                return false;
            }


            if(empty($content)){
                return false;
            }
            
            // 读写方式打开，将文件指针指向文件头并将文件大小截为零。如果文件不存在则尝试创建之
            $fp = @fopen($savedir, 'w+');
            fwrite($fp, $content);
            fclose($fp);
            unset($content, $url);
            return array(
                'file_name' => $filename,
                'save_path' => $savedir . $filename
            );
        }

    // 更新系统版本号
    public function updateVersion(){
        $version = input('version');
        $filePath = 'version/'.$version.'.sql';
        $url = 'http://iguoqin.cn/update.php'; // 要下载的文件【服务器】
        $savedir = ROOT_PATH.'upgrade/'.$version.'.sql'; // 下载后保存的路径【客户端】 


        $filename = $filePath; // 下载后保存的名字
        $rs = $this->getFile($url, $savedir, $filename, $version);
        if($rs==false)
            return WSTReturn('数据库文件下载失败',-1);
       return model('Upgrade')->updateVersion($version);
    }
    
}
